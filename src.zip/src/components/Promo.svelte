<!-- short service promo section -->
<section class="xs-section-padding">
    <div class="container">
        <div class="xs-heading xs-mb-70 text-center">
            <h2 class="xs-mb-0 xs-title">We’ve funded <span>120,00 charity projects</span> for <br> 20M people
                around the world.</h2>
        </div>
        <div class="row">
            <div class="col-md-6 col-lg-3">
                <div class="xs-service-promo">
                    <span class="icon-water"></span>
                    <h5>Pure Water <br>For Poor People</h5>
                    <p>663 million people drink dirty water. Learn how access to clean water can improve health,
                        boost local economies.</p>
                </div><!-- .xs-service-promo END -->
            </div>
            <div class="col-md-6 col-lg-3">
                <div class="xs-service-promo">
                    <span class="icon-groceries"></span>
                    <h5>Healty Food <br>For Poor People</h5>
                    <p>663 million people drink dirty water. Learn how access to clean water can improve health,
                        boost local economies.</p>
                </div><!-- .xs-service-promo END -->
            </div>
            <div class="col-md-6 col-lg-3">
                <div class="xs-service-promo">
                    <span class="icon-heartbeat"></span>
                    <h5>Medical <br>Facilities for People</h5>
                    <p>663 million people drink dirty water. Learn how access to clean water can improve health,
                        boost local economies.</p>
                </div><!-- .xs-service-promo END -->
            </div>
            <div class="col-md-6 col-lg-3">
                <div class="xs-service-promo">
                    <span class="icon-open-book"></span>
                    <h5>Pure Education <br>For Every Children</h5>
                    <p>663 million people drink dirty water. Learn how access to clean water can improve health,
                        boost local economies.</p>
                </div><!-- .xs-service-promo END -->
            </div>
        </div><!-- .row end -->
    </div><!-- .container end -->
</section><!-- End short service promo section -->