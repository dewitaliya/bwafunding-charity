<!-- header section -->
<header class="xs-header header-transparent">
    <div class="container">
        <nav class="xs-menus">
            <div class="nav-header">
                <div class="nav-toggle"></div>
                <a href="/" class="nav-logo">
                    <img src="/assets/images/logo.png" alt="">
                </a>
            </div><!-- .nav-header END -->
            <div class="nav-menus-wrapper row">
                <div class="xs-logo-wraper col-lg-2 xs-padding-0">
                    <a class="nav-brand" href="/">
                        <img src="/assets/images/logo.png" alt="">
                    </a>
                </div><!-- .xs-logo-wraper END -->
                <div class="col-lg-7">
                    <ul class="nav-menu">
                        <li><a href="/">home</a></li>
                        <li><a href="/about">about</a></li>
                        <li><a href="/contact">Contact</a></li>
                    </ul><!-- .nav-menu END -->
                </div>
                <div class="xs-navs-button d-flex-center-end col-lg-3">
                    <a href="#popularcause" class="btn btn-primary">
                        <span class="badge"><i class="fa fa-heart"></i></span> Donate Now
                    </a>
                </div><!-- .xs-navs-button END -->
            </div><!-- .nav-menus-wrapper .row END -->
        </nav><!-- .xs-menus .fundpress-menu END -->
    </div><!-- .container end -->
</header><!-- End header section -->