<!-- welcome section -->
<section>
<div>
        <div class="xs-welcome-content" style="background-image: url(assets/images/slide1.png);">
            <div class="container">
                <div class="xs-welcome-wraper color-white">
                    <h2>Hunger is stalking the globe</h2>
                    <p>Hundreds of thousands of children experiencing or witnessing assault <br> and other
                        gender-based violence.</p>
                    <a href="#popularcause" class="btn btn-outline-primary">
                        View Causes
                    </a>
                </div><!-- .xs-welcome-wraper END -->
            </div><!-- .container end -->
            <div class="xs-black-overlay"></div>
        </div><!-- .xs-welcome-content END -->
        <div class="xs-welcome-content" style="background-image: url(assets/images/slide2.png);">
            <div class="container">
                <div class="xs-welcome-wraper color-white">
                    <h2>Let's free the nature at all</h2>
                    <p>Hundreds of thousands of children experiencing or witnessing assault <br> and other
                        gender-based violence.</p>
                    <a href="#popularcause" class="btn btn-outline-primary">
                        View Causes
                    </a>
                </div><!-- .xs-welcome-wraper END -->
            </div><!-- .container end -->
            <div class="xs-black-overlay"></div>
        </div><!-- .xs-welcome-content END -->
        <div class="xs-welcome-content" style="background-image: url(assets/images/slide3.png);">
            <div class="container">
                <div class="xs-welcome-wraper color-white">
                    <h2>Help us in big mission to rescue</h2>
                    <p>Hundreds of thousands of children experiencing or witnessing assault <br> and other
                        gender-based violence.</p>
                    <a href="#popularcause" class="btn btn-outline-primary">
                        View Causes
                    </a>
                </div><!-- .xs-welcome-wraper END -->
            </div><!-- .container end -->
            <div class="xs-black-overlay"></div>
        </div><!-- .xs-welcome-content END -->
    </div>
<!-- End welcome section -->
</section>