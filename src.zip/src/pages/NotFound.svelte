<!-- notfound section -->
<section class="waypoint-tigger xs-section-padding">
    <div class="container">
      <div class="xs-heading row xs-mb-60 justify-content-center text-center">
        <div class="col-md-6 col-xl-6">
          <img
            src="https://images.unsplash.com/photo-1532003885409-ed84d334f6cc?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=500&q=60"
            alt=""
            width="450"
            height="450" />
          <h2 class="xs-title">Oops!</h2>
          <p>There is something wrong with the page. I cannot find it.</p>
          <a href="/" class="btn btn-primary mt-4">Back to the home page</a>
        </div>
        <!-- .xs-heading-title END -->
      </div>
      <!-- .row end -->
    </div>
    <!-- .container end -->
  </section>
  <!-- End notfound section -->