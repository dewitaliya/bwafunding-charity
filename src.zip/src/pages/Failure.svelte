 <section id="popularcause" class="waypoint-tigger xs-section-padding">
    <div class="container">
        <div class="xs-heading row xs-mb-60 justify-content-center text-center">
            <div class="col-md-6 col-xl-6">
                <img src="/assets/images/donation_error.png" alt="" width="450" height="450">
                <h2 class="xs-title">Oops!</h2>
                <p>There is something wrong with the payment please try again or cancel the donation.</p>
                <a href="/" class="btn btn-primary mt-4">
                    Try Again
                </a>
            </div><!-- .xs-heading-title END -->
        </div><!-- .row end -->
    </div><!-- .container end -->
</section>