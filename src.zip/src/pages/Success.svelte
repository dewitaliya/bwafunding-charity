<!-- popularCauses section -->
<section id="popularcause" class="waypoint-tigger xs-section-padding">
    <div class="container">
        <div class="xs-heading row xs-mb-60 justify-content-center text-center">
            <div class="col-md-6 col-xl-6">
                <img src="/assets/images/success_donation.png" alt="" width="450" height="450">
                <h2 class="xs-title">Wow! You Are So Kind</h2>
                <p>Your donation has been successfully transferred into their account and we will send the details
                    to your email.</p>
                <a href="/" class="btn btn-primary mt-4">
                    Back to Home
                </a>
            </div><!-- .xs-heading-title END -->
        </div><!-- .row end -->
    </div><!-- .container end -->
</section><!-- End popularCauses section -->
